# À CONTRE-PIED — mise en ligne (une seule fois)

## 1. GitHub
1. Crée un compte sur github.com (gratuit) si tu n'en as pas.
2. Crée un nouveau dépôt nommé `a-contre-pied` (Privé ou Public).
3. Sur la page du dépôt : "uploading an existing file", glisse TOUT le contenu de ce dossier (pas le zip), puis "Commit changes".

## 2. Netlify
1. app.netlify.com → Add new site → Import an existing project → GitHub → choisis `a-contre-pied`.
2. Les réglages sont déjà dans netlify.toml (build: npm run build, publish: dist). Clique Deploy.

## 3. Connexion à l'admin (GitHub OAuth)
1. GitHub → Settings → Developer settings → OAuth Apps → New OAuth App.
   - Homepage URL : l'adresse de ton site Netlify
   - Authorization callback URL : https://api.netlify.com/auth/done
2. Génère un Client secret, puis copie Client ID + Client secret.
3. Netlify → Site configuration → Access & security → OAuth → Install provider → GitHub → colle les deux.
4. Dans GitHub, ouvre `public/admin/config.yml`, remplace `TON-PSEUDO-GITHUB` par ton pseudo GitHub, et commit.

## 4. Publier un article
Va sur https://TON-SITE/admin → "Login with GitHub" → New Article → remplis le formulaire → Publish.
Le site se met à jour tout seul en ~1 minute.
